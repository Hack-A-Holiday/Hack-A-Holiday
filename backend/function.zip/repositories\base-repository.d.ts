import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';
export interface RepositoryConfig {
    tableName: string;
    region?: string;
    endpoint?: string;
}
export interface QueryOptions {
    limit?: number;
    exclusiveStartKey?: Record<string, any>;
    scanIndexForward?: boolean;
    filterExpression?: string;
    expressionAttributeNames?: Record<string, string>;
    expressionAttributeValues?: Record<string, any>;
}
export interface UpdateOptions {
    updateExpression: string;
    expressionAttributeNames?: Record<string, string>;
    expressionAttributeValues?: Record<string, any>;
    conditionExpression?: string;
}
export declare class BaseRepository {
    protected client: DynamoDBDocumentClient;
    protected tableName: string;
    constructor(config: RepositoryConfig);
    /**
     * Get a single item by primary key
     */
    getItem(key: Record<string, any>): Promise<any | null>;
    /**
     * Put an item (create or replace)
     */
    putItem(item: Record<string, any>): Promise<void>;
    /**
     * Update an item
     */
    updateItem(key: Record<string, any>, options: UpdateOptions): Promise<any>;
    /**
     * Delete an item
     */
    deleteItem(key: Record<string, any>): Promise<void>;
    /**
     * Query items
     */
    query(keyConditionExpression: string, options?: QueryOptions): Promise<{
        items: any[];
        lastEvaluatedKey?: Record<string, any>;
    }>;
    /**
     * Query items using GSI
     */
    queryGSI(indexName: string, keyConditionExpression: string, options?: QueryOptions): Promise<{
        items: any[];
        lastEvaluatedKey?: Record<string, any>;
    }>;
    /**
     * Scan table (use sparingly)
     */
    scan(options?: QueryOptions): Promise<{
        items: any[];
        lastEvaluatedKey?: Record<string, any>;
    }>;
    /**
     * Batch get items (up to 100 items)
     */
    batchGetItems(keys: Record<string, any>[]): Promise<any[]>;
    /**
     * Check if item exists
     */
    itemExists(key: Record<string, any>): Promise<boolean>;
    /**
     * Get table name (useful for testing)
     */
    getTableName(): string;
}
//# sourceMappingURL=base-repository.d.ts.map