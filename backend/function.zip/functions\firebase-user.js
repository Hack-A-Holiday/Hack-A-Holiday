"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const util_dynamodb_1 = require("@aws-sdk/util-dynamodb");
const dynamoDBClient = new client_dynamodb_1.DynamoDBClient({ region: process.env.AWS_REGION });
const USERS_TABLE = process.env.USERS_TABLE_NAME || 'TravelCompanion-Users';
const handler = async (event) => {
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    };
    try {
        // Handle CORS preflight
        if (event.httpMethod === 'OPTIONS') {
            return {
                statusCode: 200,
                headers,
                body: '',
            };
        }
        if (event.httpMethod === 'POST') {
            return await createOrUpdateUser(event);
        }
        if (event.httpMethod === 'GET') {
            return await getUser(event);
        }
        return {
            statusCode: 405,
            headers,
            body: JSON.stringify({
                error: 'Method not allowed',
                message: `HTTP method ${event.httpMethod} is not supported.`,
            }),
        };
    }
    catch (error) {
        console.error('Error processing request:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'Internal server error',
                message: error instanceof Error ? error.message : 'Unknown error occurred',
            }),
        };
    }
};
exports.handler = handler;
async function createOrUpdateUser(event) {
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
    };
    if (!event.body) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({
                error: 'Bad request',
                message: 'Request body is required',
            }),
        };
    }
    try {
        const userData = JSON.parse(event.body);
        // Validate required fields
        if (!userData.userId || !userData.email) {
            return {
                statusCode: 400,
                headers,
                body: JSON.stringify({
                    error: 'Bad request',
                    message: 'userId and email are required fields',
                }),
            };
        }
        // Check if user already exists
        const getUserCommand = new client_dynamodb_1.GetItemCommand({
            TableName: USERS_TABLE,
            Key: (0, util_dynamodb_1.marshall)({ userId: userData.userId }),
        });
        const existingUser = await dynamoDBClient.send(getUserCommand);
        const userItem = {
            userId: userData.userId,
            email: userData.email,
            displayName: userData.displayName || userData.email,
            photoURL: userData.photoURL,
            provider: userData.provider || 'firebase',
            lastLoginAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            // Keep original createdAt if user exists, otherwise set it now
            createdAt: existingUser.Item
                ? (0, util_dynamodb_1.unmarshall)(existingUser.Item).createdAt
                : userData.createdAt || new Date().toISOString(),
        };
        const putCommand = new client_dynamodb_1.PutItemCommand({
            TableName: USERS_TABLE,
            Item: (0, util_dynamodb_1.marshall)(userItem),
        });
        await dynamoDBClient.send(putCommand);
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                message: 'User stored successfully',
                user: userItem,
            }),
        };
    }
    catch (error) {
        console.error('Error storing user:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'Internal server error',
                message: error instanceof Error ? error.message : 'Failed to store user',
            }),
        };
    }
}
async function getUser(event) {
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
    };
    const userId = event.pathParameters?.userId;
    if (!userId) {
        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({
                error: 'Bad request',
                message: 'userId path parameter is required',
            }),
        };
    }
    try {
        const getCommand = new client_dynamodb_1.GetItemCommand({
            TableName: USERS_TABLE,
            Key: (0, util_dynamodb_1.marshall)({ userId }),
        });
        const result = await dynamoDBClient.send(getCommand);
        if (!result.Item) {
            return {
                statusCode: 404,
                headers,
                body: JSON.stringify({
                    error: 'Not found',
                    message: 'User not found',
                }),
            };
        }
        const user = (0, util_dynamodb_1.unmarshall)(result.Item);
        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({
                user,
            }),
        };
    }
    catch (error) {
        console.error('Error retrieving user:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                error: 'Internal server error',
                message: error instanceof Error ? error.message : 'Failed to retrieve user',
            }),
        };
    }
}
//# sourceMappingURL=firebase-user.js.map