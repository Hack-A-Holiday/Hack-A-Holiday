import { Itinerary } from '../types';
export interface S3ServiceConfig {
    bucketName: string;
    region?: string;
    endpoint?: string;
}
export interface UploadOptions {
    contentType?: string;
    metadata?: Record<string, string>;
    cacheControl?: string;
    expires?: Date;
}
export interface SignedUrlOptions {
    expiresIn?: number;
    responseContentType?: string;
    responseContentDisposition?: string;
}
export declare class S3Service {
    private client;
    private bucketName;
    constructor(config: S3ServiceConfig);
    /**
     * Upload itinerary as JSON file
     */
    uploadItinerary(userId: string | undefined, tripId: string, itinerary: Itinerary): Promise<string>;
    /**
     * Upload itinerary as PDF (placeholder - would need PDF generation library)
     */
    uploadItineraryPDF(userId: string | undefined, tripId: string, pdfBuffer: Buffer): Promise<string>;
    /**
     * Upload booking confirmations
     */
    uploadBookingConfirmations(userId: string | undefined, tripId: string, confirmations: any[]): Promise<string>;
    /**
     * Generic file upload
     */
    uploadFile(key: string, content: string | Buffer | Uint8Array, options?: UploadOptions): Promise<void>;
    /**
     * Get file content
     */
    getFile(key: string): Promise<Buffer>;
    /**
     * Get itinerary from S3
     */
    getItinerary(userId: string | undefined, tripId: string): Promise<Itinerary | null>;
    /**
     * Generate signed URL for file access
     */
    getSignedUrl(key: string, options?: SignedUrlOptions): Promise<string>;
    /**
     * Generate signed URL for itinerary
     */
    getItinerarySignedUrl(userId: string | undefined, tripId: string, format?: 'json' | 'pdf', options?: SignedUrlOptions): Promise<string>;
    /**
     * Delete file
     */
    deleteFile(key: string): Promise<void>;
    /**
     * Delete all files for a trip
     */
    deleteTripFiles(userId: string | undefined, tripId: string): Promise<void>;
    /**
     * Check if file exists
     */
    fileExists(key: string): Promise<boolean>;
    /**
     * Get file metadata
     */
    getFileMetadata(key: string): Promise<{
        contentType?: string;
        contentLength?: number;
        lastModified?: Date;
        metadata?: Record<string, string>;
    } | null>;
    /**
     * List files for a user
     */
    listUserFiles(userId: string, prefix?: string, maxKeys?: number): Promise<Array<{
        key: string;
        size?: number;
        lastModified?: Date;
        contentType?: string;
    }>>;
    /**
     * Generate key for itinerary file
     */
    private getItineraryKey;
    /**
     * Generate key for booking confirmations
     */
    private getBookingConfirmationsKey;
    /**
     * Generate prefix for all trip files
     */
    private getTripPrefix;
    /**
     * Get bucket name (useful for testing)
     */
    getBucketName(): string;
}
//# sourceMappingURL=s3-service.d.ts.map