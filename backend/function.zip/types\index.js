"use strict";
// Core data models and interfaces for the travel companion system
Object.defineProperty(exports, "__esModule", { value: true });
exports.ERROR_CODES = void 0;
exports.ERROR_CODES = {
    INVALID_INPUT: 'INVALID_INPUT',
    BUDGET_TOO_LOW: 'BUDGET_TOO_LOW',
    NO_FLIGHTS_FOUND: 'NO_FLIGHTS_FOUND',
    NO_HOTELS_FOUND: 'NO_HOTELS_FOUND',
    BEDROCK_ERROR: 'BEDROCK_ERROR',
    EXTERNAL_API_ERROR: 'EXTERNAL_API_ERROR',
    RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED',
    DATABASE_ERROR: 'DATABASE_ERROR',
    S3_ERROR: 'S3_ERROR',
    UNAUTHORIZED: 'UNAUTHORIZED',
    NOT_FOUND: 'NOT_FOUND',
    INTERNAL_ERROR: 'INTERNAL_ERROR'
};
//# sourceMappingURL=index.js.map