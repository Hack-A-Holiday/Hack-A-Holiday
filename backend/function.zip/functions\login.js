"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.login = login;
const user_repository_1 = require("../repositories/user-repository");
const auth_service_1 = require("../services/auth-service");
const lambda_utils_1 = require("../utils/lambda-utils");
const userRepository = new user_repository_1.UserRepository();
const authService = new auth_service_1.AuthService();
async function login(event, context) {
    const requestId = context.awsRequestId;
    try {
        // Parse request body
        const body = (0, lambda_utils_1.parseJsonBody)(event);
        if (!body) {
            return (0, lambda_utils_1.createErrorResponse)(400, 'Request body is required', requestId);
        }
        const { email, password } = body;
        // Validate required fields
        if (!email || !password) {
            return (0, lambda_utils_1.createErrorResponse)(400, 'Email and password are required', requestId);
        }
        // Validate email format
        if (!authService.isValidEmail(email)) {
            return (0, lambda_utils_1.createErrorResponse)(400, 'Invalid email format', requestId);
        }
        // Authenticate user
        const user = await userRepository.authenticateUser(email, password);
        if (!user) {
            return (0, lambda_utils_1.createErrorResponse)(401, 'Invalid email or password', requestId);
        }
        // Generate JWT token
        const token = authService.generateToken(authService.createUserResponse(user));
        const response = {
            success: true,
            user: authService.createUserResponse(user),
            token,
            message: 'Login successful',
        };
        return (0, lambda_utils_1.createResponse)(200, response, requestId);
    }
    catch (error) {
        console.error('Login error:', error);
        const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
        return (0, lambda_utils_1.createErrorResponse)(500, errorMessage, requestId);
    }
}
//# sourceMappingURL=login.js.map