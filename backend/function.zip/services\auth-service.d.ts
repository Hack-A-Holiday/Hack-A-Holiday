import { UserProfile } from '../types';
export declare class AuthService {
    private readonly jwtSecret;
    private readonly googleClient;
    constructor();
    /**
     * Generate JWT token for authenticated user
     */
    generateToken(user: Omit<UserProfile, 'password'>): string;
    /**
     * Verify and decode JWT token
     */
    verifyToken(token: string): any;
    /**
     * Verify Google OAuth token
     */
    verifyGoogleToken(googleToken: string): Promise<{
        googleId: string;
        email: string;
        name: string;
        profilePicture: string;
    }>;
    /**
     * Extract bearer token from authorization header
     */
    extractBearerToken(authHeader?: string): string | null;
    /**
     * Validate email format
     */
    isValidEmail(email: string): boolean;
    /**
     * Validate password strength
     */
    isValidPassword(password: string): {
        valid: boolean;
        message?: string;
    };
    /**
     * Create user response (excludes sensitive data)
     */
    createUserResponse(user: UserProfile): Omit<UserProfile, 'password'>;
}
//# sourceMappingURL=auth-service.d.ts.map