"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.withCorsHeaders = withCorsHeaders;
function withCorsHeaders(handler) {
    return async (event, context) => {
        try {
            const response = await handler(event, context);
            return {
                ...response,
                headers: {
                    ...response.headers,
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                    'Access-Control-Allow-Credentials': true,
                },
            };
        }
        catch (error) {
            return {
                statusCode: 500,
                headers: {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET,PUT,DELETE',
                    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
                    'Access-Control-Allow-Credentials': true,
                },
                body: JSON.stringify({ error: 'Internal server error' }),
            };
        }
    };
}
//# sourceMappingURL=cors-middleware.js.map