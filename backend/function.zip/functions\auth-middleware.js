"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authenticateUser = authenticateUser;
exports.withAuth = withAuth;
exports.me = me;
const user_repository_1 = require("../repositories/user-repository");
const auth_service_1 = require("../services/auth-service");
const lambda_utils_1 = require("../utils/lambda-utils");
const authService = new auth_service_1.AuthService();
const userRepository = new user_repository_1.UserRepository();
async function authenticateUser(event, context) {
    const requestId = context.awsRequestId;
    try {
        // Extract token from Authorization header
        const authHeader = event.headers.Authorization || event.headers.authorization;
        const token = authService.extractBearerToken(authHeader);
        if (!token) {
            return {
                user: null,
                error: (0, lambda_utils_1.createErrorResponse)(401, 'Authorization token is required', requestId),
            };
        }
        // Verify JWT token
        let tokenPayload;
        try {
            tokenPayload = authService.verifyToken(token);
        }
        catch (error) {
            console.warn('Token verification failed in middleware:', error instanceof Error ? error.message : 'Unknown error');
            return {
                user: null,
                error: (0, lambda_utils_1.createErrorResponse)(401, 'Invalid or expired token', requestId),
            };
        }
        // Verify user still exists
        const user = await userRepository.getUserById(tokenPayload.userId);
        if (!user) {
            return {
                user: null,
                error: (0, lambda_utils_1.createErrorResponse)(401, 'User not found', requestId),
            };
        }
        return {
            user: {
                userId: user.id,
                email: user.email,
                role: user.role,
                name: user.name,
            },
        };
    }
    catch (error) {
        console.error('Authentication error:', error);
        return {
            user: null,
            error: (0, lambda_utils_1.createErrorResponse)(500, 'Authentication failed', requestId),
        };
    }
}
/**
 * Higher-order function to protect Lambda routes
 */
function withAuth(handler) {
    return async (event, context) => {
        // Authenticate user
        const { user, error } = await authenticateUser(event, context);
        if (error) {
            return error;
        }
        // Add user info to event
        const authenticatedEvent = {
            ...event,
            user,
        };
        // Call the original handler
        return handler(authenticatedEvent, context);
    };
}
/**
 * Get current user profile
 */
async function me(event, context) {
    const requestId = context.awsRequestId;
    const { user, error } = await authenticateUser(event, context);
    if (error) {
        return error;
    }
    try {
        // Get full user profile
        const fullUser = await userRepository.getUserById(user.userId);
        if (!fullUser) {
            return (0, lambda_utils_1.createErrorResponse)(404, 'User not found', requestId);
        }
        const response = {
            success: true,
            user: authService.createUserResponse(fullUser),
        };
        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
            },
            body: JSON.stringify(response),
        };
    }
    catch (error) {
        console.error('Get user profile error:', error);
        const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
        return (0, lambda_utils_1.createErrorResponse)(500, errorMessage, requestId);
    }
}
//# sourceMappingURL=auth-middleware.js.map