import { Itinerary } from '../types';
/**
 * Generate PDF content for itinerary
 * Note: This is a simplified HTML-to-PDF approach
 * In production, you might want to use libraries like puppeteer, jsPDF, or PDFKit
 */
export declare class PDFGenerator {
    /**
     * Generate HTML content that can be converted to PDF
     */
    static generateItineraryHTML(itinerary: Itinerary): string;
    private static generateFlightsSection;
    private static generateFlightCard;
    private static generateHotelsSection;
    private static generateHotelCard;
    private static generateDailyItinerarySection;
    private static generateDayCard;
    private static generateBudgetBreakdownSection;
    /**
     * Convert HTML to PDF buffer
     * Note: This is a placeholder implementation
     * In production, you would use a library like puppeteer:
     *
     * import puppeteer from 'puppeteer';
     *
     * static async htmlToPDF(html: string): Promise<Buffer> {
     *   const browser = await puppeteer.launch();
     *   const page = await browser.newPage();
     *   await page.setContent(html);
     *   const pdf = await page.pdf({
     *     format: 'A4',
     *     printBackground: true,
     *     margin: { top: '20px', bottom: '20px', left: '20px', right: '20px' }
     *   });
     *   await browser.close();
     *   return Buffer.from(pdf);
     * }
     */
    static htmlToPDF(html: string): Promise<Buffer>;
    /**
     * Generate PDF buffer for itinerary
     */
    static generateItineraryPDF(itinerary: Itinerary): Promise<Buffer>;
}
//# sourceMappingURL=pdf-generator.d.ts.map