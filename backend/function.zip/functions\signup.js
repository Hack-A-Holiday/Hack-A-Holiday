"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.signup = signup;
const user_repository_1 = require("../repositories/user-repository");
const auth_service_1 = require("../services/auth-service");
const lambda_utils_1 = require("../utils/lambda-utils");
const userRepository = new user_repository_1.UserRepository();
const authService = new auth_service_1.AuthService();
async function signup(event, context) {
    const requestId = context.awsRequestId;
    try {
        // Parse request body
        const body = (0, lambda_utils_1.parseJsonBody)(event);
        if (!body) {
            return (0, lambda_utils_1.createErrorResponse)(400, 'Request body is required', requestId);
        }
        const { email, password, name, preferences } = body;
        // Validate required fields
        if (!email || !password) {
            return (0, lambda_utils_1.createErrorResponse)(400, 'Email and password are required', requestId);
        }
        // Validate email format
        if (!authService.isValidEmail(email)) {
            return (0, lambda_utils_1.createErrorResponse)(400, 'Invalid email format', requestId);
        }
        // Validate password strength
        const passwordValidation = authService.isValidPassword(password);
        if (!passwordValidation.valid) {
            return (0, lambda_utils_1.createErrorResponse)(400, passwordValidation.message, requestId);
        }
        // Check if user already exists
        const existingUser = await userRepository.getUserByEmail(email);
        if (existingUser) {
            return (0, lambda_utils_1.createErrorResponse)(409, 'An account with this email already exists', requestId);
        }
        // Create new user
        const userData = {
            email,
            password,
            role: 'normal',
            name,
            preferences: {
                defaultBudget: preferences?.defaultBudget || 2000,
                favoriteDestinations: preferences?.favoriteDestinations || [],
                interests: preferences?.interests || [],
                travelStyle: preferences?.travelStyle || 'mid-range',
                dietaryRestrictions: preferences?.dietaryRestrictions || [],
                accessibility: preferences?.accessibility || [],
            },
            tripHistory: [],
            isEmailVerified: false, // In production, implement email verification
        };
        const newUser = await userRepository.createUser(userData);
        // Generate JWT token
        const token = authService.generateToken(authService.createUserResponse(newUser));
        const response = {
            success: true,
            user: authService.createUserResponse(newUser),
            token,
            message: 'Account created successfully',
        };
        return (0, lambda_utils_1.createResponse)(201, response, requestId);
    }
    catch (error) {
        console.error('Signup error:', error);
        const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
        return (0, lambda_utils_1.createErrorResponse)(500, errorMessage, requestId);
    }
}
//# sourceMappingURL=signup.js.map