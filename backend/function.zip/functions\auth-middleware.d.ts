import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
export interface AuthenticatedEvent extends APIGatewayProxyEvent {
    user?: {
        userId: string;
        email: string;
        role: 'normal' | 'google';
        name?: string;
    };
}
export declare function authenticateUser(event: APIGatewayProxyEvent, context: Context): Promise<{
    user: any;
    error?: APIGatewayProxyResult;
}>;
/**
 * Higher-order function to protect Lambda routes
 */
export declare function withAuth(handler: (event: AuthenticatedEvent, context: Context) => Promise<APIGatewayProxyResult>): (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>;
/**
 * Get current user profile
 */
export declare function me(event: APIGatewayProxyEvent, context: Context): Promise<APIGatewayProxyResult>;
//# sourceMappingURL=auth-middleware.d.ts.map