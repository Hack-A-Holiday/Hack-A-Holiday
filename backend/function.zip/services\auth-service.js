"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const jwt = __importStar(require("jsonwebtoken"));
const google_auth_library_1 = require("google-auth-library");
class AuthService {
    constructor() {
        const jwtSecret = process.env.JWT_SECRET;
        if (!jwtSecret) {
            throw new Error('JWT_SECRET environment variable is required');
        }
        this.jwtSecret = jwtSecret;
        const googleClientId = process.env.GOOGLE_CLIENT_ID;
        if (!googleClientId) {
            throw new Error('GOOGLE_CLIENT_ID environment variable is required');
        }
        this.googleClient = new google_auth_library_1.OAuth2Client(googleClientId);
    }
    /**
     * Generate JWT token for authenticated user
     */
    generateToken(user) {
        const payload = {
            userId: user.id,
            email: user.email,
            role: user.role,
            name: user.name,
        };
        return jwt.sign(payload, this.jwtSecret, {
            expiresIn: '7d', // Token expires in 7 days
            issuer: 'travel-companion',
            subject: user.id,
        });
    }
    /**
     * Verify and decode JWT token
     */
    verifyToken(token) {
        try {
            return jwt.verify(token, this.jwtSecret);
        }
        catch (error) {
            console.error('Token verification failed:', error instanceof Error ? error.message : 'Unknown error');
            throw new Error('Invalid or expired token');
        }
    }
    /**
     * Verify Google OAuth token
     */
    async verifyGoogleToken(googleToken) {
        try {
            const ticket = await this.googleClient.verifyIdToken({
                idToken: googleToken,
                audience: process.env.GOOGLE_CLIENT_ID,
            });
            const payload = ticket.getPayload();
            if (!payload) {
                throw new Error('Invalid Google token payload');
            }
            return {
                googleId: payload.sub,
                email: payload.email || '',
                name: payload.name || '',
                profilePicture: payload.picture || '',
            };
        }
        catch (error) {
            console.error('Google token verification failed:', error instanceof Error ? error.message : 'Unknown error');
            throw new Error('Invalid Google token');
        }
    }
    /**
     * Extract bearer token from authorization header
     */
    extractBearerToken(authHeader) {
        if (!authHeader?.startsWith('Bearer ')) {
            return null;
        }
        return authHeader.substring(7); // Remove 'Bearer ' prefix
    }
    /**
     * Validate email format
     */
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    /**
     * Validate password strength
     */
    isValidPassword(password) {
        if (password.length < 8) {
            return { valid: false, message: 'Password must be at least 8 characters long' };
        }
        if (!/(?=.*[a-z])/.test(password)) {
            return { valid: false, message: 'Password must contain at least one lowercase letter' };
        }
        if (!/(?=.*[A-Z])/.test(password)) {
            return { valid: false, message: 'Password must contain at least one uppercase letter' };
        }
        if (!/(?=.*\d)/.test(password)) {
            return { valid: false, message: 'Password must contain at least one number' };
        }
        return { valid: true };
    }
    /**
     * Create user response (excludes sensitive data)
     */
    createUserResponse(user) {
        const { password, ...userResponse } = user;
        return userResponse;
    }
}
exports.AuthService = AuthService;
//# sourceMappingURL=auth-service.js.map