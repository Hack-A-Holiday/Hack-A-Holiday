"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TripRepository = void 0;
const crypto_1 = require("crypto");
const base_repository_1 = require("./base-repository");
class TripRepository extends base_repository_1.BaseRepository {
    constructor(config) {
        super({
            tableName: config?.tableName || process.env.TRIPS_TABLE_NAME || 'TravelCompanion-Trips',
            region: config?.region,
            endpoint: config?.endpoint,
        });
    }
    /**
     * Create a new trip
     */
    async createTrip(preferences, userId) {
        const tripId = (0, crypto_1.randomUUID)();
        const now = new Date().toISOString();
        const tripRecord = {
            PK: `TRIP#${tripId}`,
            SK: 'METADATA',
            GSI1PK: userId ? `USER#${userId}` : undefined,
            GSI1SK: `TRIP#${now}`,
            userId,
            destination: preferences.destination,
            status: 'draft',
            preferences,
            itinerary: {
                id: tripId,
                userId,
                destination: preferences.destination,
                startDate: preferences.startDate,
                endDate: this.calculateEndDate(preferences.startDate, preferences.duration),
                totalCost: 0,
                budgetBreakdown: {
                    flights: 0,
                    accommodation: 0,
                    activities: 0,
                    meals: 0,
                    transportation: 0,
                    miscellaneous: 0,
                },
                days: [],
                flights: {},
                hotels: [],
                status: 'draft',
                createdAt: now,
                updatedAt: now,
                confidence: 0,
            },
            totalCost: 0,
            createdAt: now,
            updatedAt: now,
        };
        await this.putItem(tripRecord);
        return tripId;
    }
    /**
     * Get trip by ID
     */
    async getTripById(tripId) {
        const key = {
            PK: `TRIP#${tripId}`,
            SK: 'METADATA',
        };
        const record = await this.getItem(key);
        if (!record)
            return null;
        return record.itinerary;
    }
    /**
     * Update trip itinerary
     */
    async updateTripItinerary(tripId, itinerary) {
        const key = {
            PK: `TRIP#${tripId}`,
            SK: 'METADATA',
        };
        const updatedItinerary = {
            ...itinerary,
            updatedAt: new Date().toISOString(),
        };
        const result = await this.updateItem(key, {
            updateExpression: 'SET itinerary = :itinerary, totalCost = :totalCost, #status = :status, updatedAt = :updatedAt',
            expressionAttributeNames: {
                '#status': 'status',
            },
            expressionAttributeValues: {
                ':itinerary': updatedItinerary,
                ':totalCost': itinerary.totalCost,
                ':status': itinerary.status,
            },
        });
        return result.itinerary;
    }
    /**
     * Update trip status
     */
    async updateTripStatus(tripId, status) {
        const key = {
            PK: `TRIP#${tripId}`,
            SK: 'METADATA',
        };
        await this.updateItem(key, {
            updateExpression: 'SET #status = :status, updatedAt = :updatedAt',
            expressionAttributeNames: {
                '#status': 'status',
            },
            expressionAttributeValues: {
                ':status': status,
            },
        });
        // Also update the status in the itinerary
        const trip = await this.getTripById(tripId);
        if (trip) {
            trip.status = status;
            await this.updateTripItinerary(tripId, trip);
        }
    }
    /**
     * Get trips by user ID
     */
    async getTripsByUserId(userId, limit = 20, lastEvaluatedKey) {
        const result = await this.queryGSI('GSI1', 'GSI1PK = :userId', {
            expressionAttributeValues: {
                ':userId': `USER#${userId}`,
            },
            limit,
            exclusiveStartKey: lastEvaluatedKey,
            scanIndexForward: false, // Most recent first
        });
        const trips = result.items.map(record => record.itinerary);
        return {
            trips,
            lastEvaluatedKey: result.lastEvaluatedKey,
        };
    }
    /**
     * Get trips by destination
     */
    async getTripsByDestination(destination, limit = 50) {
        const result = await this.scan({
            filterExpression: 'contains(destination, :destination)',
            expressionAttributeValues: {
                ':destination': destination,
            },
            limit,
        });
        return result.items.map(record => record.itinerary);
    }
    /**
     * Get trips by status
     */
    async getTripsByStatus(status, limit = 100) {
        const result = await this.scan({
            filterExpression: '#status = :status',
            expressionAttributeNames: {
                '#status': 'status',
            },
            expressionAttributeValues: {
                ':status': status,
            },
            limit,
        });
        return result.items.map(record => record.itinerary);
    }
    /**
     * Get recent trips (for analytics)
     */
    async getRecentTrips(days = 30, limit = 100) {
        const cutoffDate = new Date();
        cutoffDate.setDate(cutoffDate.getDate() - days);
        const cutoffIso = cutoffDate.toISOString();
        const result = await this.scan({
            filterExpression: 'createdAt >= :cutoff',
            expressionAttributeValues: {
                ':cutoff': cutoffIso,
            },
            limit,
        });
        return result.items
            .map(record => record.itinerary)
            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }
    /**
     * Get trips by budget range
     */
    async getTripsByBudgetRange(minBudget, maxBudget, limit = 50) {
        const result = await this.scan({
            filterExpression: 'totalCost BETWEEN :min AND :max',
            expressionAttributeValues: {
                ':min': minBudget,
                ':max': maxBudget,
            },
            limit,
        });
        return result.items.map(record => record.itinerary);
    }
    /**
     * Delete trip
     */
    async deleteTrip(tripId) {
        const key = {
            PK: `TRIP#${tripId}`,
            SK: 'METADATA',
        };
        await this.deleteItem(key);
    }
    /**
     * Check if trip exists
     */
    async tripExists(tripId) {
        const key = {
            PK: `TRIP#${tripId}`,
            SK: 'METADATA',
        };
        return await this.itemExists(key);
    }
    /**
     * Get trip statistics
     */
    async getTripStatistics() {
        // This is a simplified implementation
        // In production, you might want to use DynamoDB Streams or separate analytics tables
        const result = await this.scan({ limit: 1000 });
        const trips = result.items.map(record => record.itinerary);
        const totalTrips = trips.length;
        const tripsByStatus = trips.reduce((acc, trip) => {
            acc[trip.status] = (acc[trip.status] || 0) + 1;
            return acc;
        }, {});
        const averageBudget = trips.length > 0
            ? trips.reduce((sum, trip) => sum + trip.totalCost, 0) / trips.length
            : 0;
        const destinationCounts = trips.reduce((acc, trip) => {
            acc[trip.destination] = (acc[trip.destination] || 0) + 1;
            return acc;
        }, {});
        const popularDestinations = Object.entries(destinationCounts)
            .map(([destination, count]) => ({ destination, count: count }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 10);
        return {
            totalTrips,
            tripsByStatus,
            averageBudget: Math.round(averageBudget * 100) / 100,
            popularDestinations,
        };
    }
    /**
     * Search trips by multiple criteria
     */
    async searchTrips(criteria, limit = 50) {
        let filterExpressions = [];
        let expressionAttributeValues = {};
        let expressionAttributeNames = {};
        if (criteria.destination) {
            filterExpressions.push('contains(destination, :destination)');
            expressionAttributeValues[':destination'] = criteria.destination;
        }
        if (criteria.status) {
            filterExpressions.push('#status = :status');
            expressionAttributeNames['#status'] = 'status';
            expressionAttributeValues[':status'] = criteria.status;
        }
        if (criteria.minBudget !== undefined && criteria.maxBudget !== undefined) {
            filterExpressions.push('totalCost BETWEEN :minBudget AND :maxBudget');
            expressionAttributeValues[':minBudget'] = criteria.minBudget;
            expressionAttributeValues[':maxBudget'] = criteria.maxBudget;
        }
        else if (criteria.minBudget !== undefined) {
            filterExpressions.push('totalCost >= :minBudget');
            expressionAttributeValues[':minBudget'] = criteria.minBudget;
        }
        else if (criteria.maxBudget !== undefined) {
            filterExpressions.push('totalCost <= :maxBudget');
            expressionAttributeValues[':maxBudget'] = criteria.maxBudget;
        }
        if (criteria.startDate) {
            filterExpressions.push('itinerary.startDate >= :startDate');
            expressionAttributeValues[':startDate'] = criteria.startDate;
        }
        if (criteria.endDate) {
            filterExpressions.push('itinerary.endDate <= :endDate');
            expressionAttributeValues[':endDate'] = criteria.endDate;
        }
        // If searching by userId, use GSI query, otherwise scan
        if (criteria.userId) {
            const result = await this.queryGSI('GSI1', 'GSI1PK = :userId', {
                expressionAttributeValues: {
                    ':userId': `USER#${criteria.userId}`,
                    ...expressionAttributeValues,
                },
                expressionAttributeNames,
                filterExpression: filterExpressions.length > 0
                    ? filterExpressions.join(' AND ')
                    : undefined,
                limit,
            });
            return result.items.map(record => record.itinerary);
        }
        else {
            const result = await this.scan({
                filterExpression: filterExpressions.length > 0
                    ? filterExpressions.join(' AND ')
                    : undefined,
                expressionAttributeValues: Object.keys(expressionAttributeValues).length > 0
                    ? expressionAttributeValues
                    : undefined,
                expressionAttributeNames: Object.keys(expressionAttributeNames).length > 0
                    ? expressionAttributeNames
                    : undefined,
                limit,
            });
            return result.items.map(record => record.itinerary);
        }
    }
    /**
     * Helper method to calculate end date
     */
    calculateEndDate(startDate, duration) {
        const start = new Date(startDate);
        const end = new Date(start);
        end.setDate(start.getDate() + duration);
        return end.toISOString().split('T')[0];
    }
}
exports.TripRepository = TripRepository;
//# sourceMappingURL=trip-repository.js.map