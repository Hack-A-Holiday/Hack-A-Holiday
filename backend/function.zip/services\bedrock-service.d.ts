import { TripPreferences, Itinerary, FlightOption, HotelOption, Activity, DayPlan } from '../types';
export interface BedrockServiceConfig {
    region?: string;
    modelId?: string;
}
export declare class BedrockService {
    private client;
    private modelId;
    constructor(config?: BedrockServiceConfig);
    /**
     * Generate a complete trip itinerary using Claude
     */
    generateTripItinerary(preferences: TripPreferences, flights: FlightOption[], hotels: HotelOption[], activities: Activity[]): Promise<Itinerary>;
    /**
     * Get activity recommendations based on destination and interests
     */
    getActivityRecommendations(destination: string, interests: string[], budget: number, duration: number): Promise<Activity[]>;
    /**
     * Optimize itinerary based on budget constraints
     */
    optimizeItinerary(itinerary: Itinerary, preferences: TripPreferences): Promise<Itinerary>;
    /**
     * Generate day-by-day schedule
     */
    generateDailySchedule(preferences: TripPreferences, selectedActivities: Activity[], hotel: HotelOption): Promise<DayPlan[]>;
    /**
     * Invoke Claude model with the given prompt
     */
    private invokeModel;
    /**
     * Build comprehensive trip planning prompt
     */
    private buildTripPlanningPrompt;
    /**
     * Parse Claude's response into structured itinerary
     */
    private parseItineraryResponse;
    /**
     * Parse activities response from Claude
     */
    private parseActivitiesResponse;
    /**
     * Parse daily schedule response
     */
    private parseDailyScheduleResponse;
    /**
     * Generate fallback itinerary if Bedrock fails
     */
    private generateFallbackItinerary;
    /**
     * Generate basic daily plans
     */
    private generateBasicDailyPlans;
    /**
     * Generate basic meals for a day
     */
    private generateBasicMeals;
    /**
     * Generate basic transportation
     */
    private generateBasicTransportation;
    /**
     * Get fallback activities
     */
    private getFallbackActivities;
    /**
     * Apply optimizations to itinerary
     */
    private applyOptimizations;
    /**
     * Calculate date for a given day offset
     */
    private calculateDate;
    /**
     * Calculate end date
     */
    private calculateEndDate;
    /**
     * Calculate cost for a day
     */
    private calculateDayCost;
}
//# sourceMappingURL=bedrock-service.d.ts.map