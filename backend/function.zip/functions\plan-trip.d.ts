import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const planTrip: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const getTrip: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const listTrips: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=plan-trip.d.ts.map