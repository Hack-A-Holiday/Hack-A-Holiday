"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.VALID_INTERESTS = exports.bookingRequestSchema = exports.tripPreferencesSchema = void 0;
exports.validateTripPreferences = validateTripPreferences;
exports.validateBookingRequest = validateBookingRequest;
exports.validateBudgetAllocation = validateBudgetAllocation;
exports.validateDateRange = validateDateRange;
exports.validateInterests = validateInterests;
const joi_1 = __importDefault(require("joi"));
// Validation schemas
exports.tripPreferencesSchema = joi_1.default.object({
    destination: joi_1.default.string().min(2).max(100).required()
        .messages({
        'string.empty': 'Destination is required',
        'string.min': 'Destination must be at least 2 characters',
        'string.max': 'Destination must be less than 100 characters'
    }),
    budget: joi_1.default.number().min(100).max(100000).required()
        .messages({
        'number.base': 'Budget must be a number',
        'number.min': 'Budget must be at least $100',
        'number.max': 'Budget must be less than $100,000'
    }),
    duration: joi_1.default.number().integer().min(1).max(30).required()
        .messages({
        'number.base': 'Duration must be a number',
        'number.integer': 'Duration must be a whole number of days',
        'number.min': 'Trip must be at least 1 day',
        'number.max': 'Trip cannot exceed 30 days'
    }),
    interests: joi_1.default.array().items(joi_1.default.string().min(1).max(50)).min(1).max(10).required()
        .messages({
        'array.min': 'Please select at least one interest',
        'array.max': 'Please select no more than 10 interests'
    }),
    startDate: joi_1.default.string().isoDate().required()
        .custom((value, helpers) => {
        const date = new Date(value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (date < today) {
            return helpers.error('date.past');
        }
        const maxDate = new Date();
        maxDate.setFullYear(maxDate.getFullYear() + 2);
        if (date > maxDate) {
            return helpers.error('date.future');
        }
        return value;
    })
        .messages({
        'string.isoDate': 'Start date must be a valid date',
        'date.past': 'Start date cannot be in the past',
        'date.future': 'Start date cannot be more than 2 years in the future'
    }),
    travelers: joi_1.default.number().integer().min(1).max(20).required()
        .messages({
        'number.base': 'Number of travelers must be a number',
        'number.integer': 'Number of travelers must be a whole number',
        'number.min': 'Must have at least 1 traveler',
        'number.max': 'Cannot exceed 20 travelers'
    }),
    travelStyle: joi_1.default.string().valid('budget', 'mid-range', 'luxury').optional(),
    accommodationType: joi_1.default.string().valid('hotel', 'hostel', 'apartment', 'any').optional()
});
exports.bookingRequestSchema = joi_1.default.object({
    itineraryId: joi_1.default.string().uuid().required()
        .messages({
        'string.empty': 'Itinerary ID is required',
        'string.uuid': 'Invalid itinerary ID format'
    }),
    userId: joi_1.default.string().uuid().optional(),
    selectedOptions: joi_1.default.object({
        flightIds: joi_1.default.array().items(joi_1.default.string().uuid()).min(1).max(2).required()
            .messages({
            'array.min': 'At least one flight must be selected',
            'array.max': 'Cannot select more than 2 flights (outbound and return)'
        }),
        hotelId: joi_1.default.string().uuid().required()
            .messages({
            'string.empty': 'Hotel selection is required'
        }),
        activityIds: joi_1.default.array().items(joi_1.default.string().uuid()).max(20).optional()
            .messages({
            'array.max': 'Cannot select more than 20 activities'
        })
    }).required()
});
// Validation functions
function validateTripPreferences(data) {
    const { error, value } = exports.tripPreferencesSchema.validate(data, {
        abortEarly: false,
        stripUnknown: true
    });
    if (error) {
        const errors = error.details.map(detail => detail.message);
        return { isValid: false, errors };
    }
    return { isValid: true, data: value };
}
function validateBookingRequest(data) {
    const { error, value } = exports.bookingRequestSchema.validate(data, {
        abortEarly: false,
        stripUnknown: true
    });
    if (error) {
        const errors = error.details.map(detail => detail.message);
        return { isValid: false, errors };
    }
    return { isValid: true, data: value };
}
// Budget validation utilities
function validateBudgetAllocation(totalBudget, flightCost, hotelCost, activityCost) {
    const breakdown = {
        flights: flightCost,
        hotels: hotelCost,
        activities: activityCost,
        total: flightCost + hotelCost + activityCost,
        remaining: totalBudget - (flightCost + hotelCost + activityCost)
    };
    if (breakdown.total > totalBudget) {
        return {
            isValid: false,
            message: `Total cost ($${breakdown.total}) exceeds budget ($${totalBudget})`,
            breakdown
        };
    }
    // Check if flight cost is too high (should be max 50% of budget)
    if (flightCost > totalBudget * 0.5) {
        return {
            isValid: false,
            message: `Flight cost ($${flightCost}) exceeds 50% of budget ($${totalBudget * 0.5})`,
            breakdown
        };
    }
    // Check if hotel cost is too high (should be max 40% of budget)
    if (hotelCost > totalBudget * 0.4) {
        return {
            isValid: false,
            message: `Hotel cost ($${hotelCost}) exceeds 40% of budget ($${totalBudget * 0.4})`,
            breakdown
        };
    }
    return { isValid: true, breakdown };
}
// Date validation utilities
function validateDateRange(startDate, duration) {
    try {
        const start = new Date(startDate);
        const end = new Date(start);
        end.setDate(start.getDate() + duration);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (start < today) {
            return {
                isValid: false,
                message: 'Start date cannot be in the past'
            };
        }
        const maxDate = new Date();
        maxDate.setFullYear(maxDate.getFullYear() + 2);
        if (end > maxDate) {
            return {
                isValid: false,
                message: 'Trip end date cannot be more than 2 years in the future'
            };
        }
        return {
            isValid: true,
            endDate: end.toISOString().split('T')[0]
        };
    }
    catch (error) {
        return {
            isValid: false,
            message: 'Invalid date format'
        };
    }
}
// Interest validation
exports.VALID_INTERESTS = [
    'culture', 'history', 'museums', 'art', 'architecture',
    'food', 'nightlife', 'shopping', 'nature', 'hiking',
    'beaches', 'adventure', 'sports', 'photography',
    'music', 'festivals', 'local-experiences', 'wellness',
    'family-friendly', 'budget-friendly', 'luxury'
];
function validateInterests(interests) {
    const validInterests = interests.filter(interest => exports.VALID_INTERESTS.includes(interest.toLowerCase()));
    const invalidInterests = interests.filter(interest => !exports.VALID_INTERESTS.includes(interest.toLowerCase()));
    return {
        isValid: invalidInterests.length === 0,
        validInterests,
        invalidInterests
    };
}
//# sourceMappingURL=validation.js.map