import { HotelOption, TripPreferences } from '../types';
export interface HotelServiceConfig {
    bookingApiKey?: string;
    amadeuApiKey?: string;
    amadeuApiSecret?: string;
    rapidApiKey?: string;
}
export declare class HotelService {
    private bookingApiKey;
    private amadeuApiKey;
    private amadeuApiSecret;
    private rapidApiKey;
    private amadeuToken;
    private tokenExpiry;
    constructor(config?: HotelServiceConfig);
    /**
     * Search for hotels based on trip preferences
     */
    searchHotels(preferences: TripPreferences): Promise<HotelOption[]>;
    /**
     * Get hotel details by ID
     */
    getHotelDetails(hotelId: string): Promise<HotelOption | null>;
    /**
     * Search hotels using Amadeus API
     */
    private searchAmadeusHotels;
    /**
     * Search hotels using Booking.com API
     */
    private searchBookingHotels;
    /**
     * Search hotels using RapidAPI
     */
    private searchRapidApiHotels;
    /**
     * Generate realistic mock hotels with real-world pricing
     */
    private generateRealisticMockHotels;
    /**
     * Ensure Amadeus token is valid
     */
    private ensureAmadeusToken;
    /**
     * Parse Amadeus hotels response
     */
    private parseAmadeusHotels;
    /**
     * Parse Booking.com hotels response
     */
    private parseBookingHotels;
    /**
     * Parse RapidAPI hotels response
     */
    private parseRapidApiHotels;
    /**
     * Get Amadeus hotel details
     */
    private getAmadeusHotelDetails;
    /**
     * Get city code for Amadeus API
     */
    private getCityCode;
    /**
     * Get Booking.com destination ID
     */
    private getBookingDestId;
    /**
     * Calculate base hotel price based on destination and travel style
     */
    private calculateBaseHotelPrice;
    /**
     * Calculate check-out date
     */
    private calculateCheckOutDate;
    /**
     * Generate hotel address
     */
    private generateHotelAddress;
    /**
     * Generate hotel images
     */
    private generateHotelImages;
    /**
     * Generate hotel description
     */
    private generateHotelDescription;
    /**
     * Get room type based on travelers and style
     */
    private getRoomType;
    /**
     * Parse rating from various formats
     */
    private parseRating;
    /**
     * Parse amenities from API response
     */
    private parseAmenities;
    /**
     * Parse Booking.com amenities
     */
    private parseBookingAmenities;
}
//# sourceMappingURL=hotel-service.d.ts.map