/**
 * Flight Recommendation Engine
 *
 * Implements advanced flight recommendation algorithms following enterprise-grade patterns.
 * Provides intelligent flight scoring, filtering, and personalized recommendations.
 *
 * @author Travel Companion Team
 * @version 1.0.0
 */
import { FlightOption, FlightSearchFilters, FlightSearchPreferences, FlightRecommendations, FlightSortOption } from '../types';
/**
 * Configuration for the recommendation engine
 */
export interface RecommendationEngineConfig {
    weights: {
        price: number;
        duration: number;
        convenience: number;
        directFlights: number;
        timePreference: number;
        airline: number;
    };
    thresholds: {
        maxPriceMultiplier: number;
        maxDurationMultiplier: number;
        minScore: number;
    };
}
/**
 * Flight Recommendation Engine
 *
 * Implements sophisticated algorithms for flight scoring and recommendation.
 * Follows Google/Meta engineering standards with clean architecture.
 */
export declare class FlightRecommendationEngine {
    private readonly config;
    constructor(config?: Partial<RecommendationEngineConfig>);
    /**
     * Calculate comprehensive score for a flight based on user preferences
     *
     * @param flight - The flight option to score
     * @param preferences - User's travel preferences
     * @param filters - Applied search filters
     * @returns Score between 0 and 1 (higher is better)
     */
    calculateScore(flight: FlightOption, preferences: FlightSearchPreferences, filters: FlightSearchFilters): number;
    /**
     * Get comprehensive flight recommendations
     */
    getRecommendations(flights: FlightOption[], preferences: FlightSearchPreferences): FlightRecommendations;
    /**
     * Apply filters to flight results
     */
    applyFilters(flights: FlightOption[], filters: FlightSearchFilters): FlightOption[];
    /**
     * Sort flights by specified criteria
     */
    sortFlights(flights: FlightOption[], sortBy: FlightSortOption): FlightOption[];
    private calculatePriceScore;
    private calculateDurationScore;
    private calculateConvenienceScore;
    private calculateDirectFlightScore;
    private calculateTimePreferenceScore;
    private calculateAirlineScore;
    private getTravelStyleModifier;
    private getPriceStyleMultiplier;
    private findBestPrice;
    private findBestValue;
    private findFastest;
    private findMostConvenient;
    private parseTime;
    private getTimeOfDay;
    private getEmptyRecommendations;
}
//# sourceMappingURL=flight-recommendation-engine.d.ts.map