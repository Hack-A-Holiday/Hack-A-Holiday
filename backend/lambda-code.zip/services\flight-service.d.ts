import { FlightOption, TripPreferences, FlightSearchRequest, FlightSearchResponse } from '../types';
export interface FlightServiceConfig {
    amadeuApiKey?: string;
    amadeuApiSecret?: string;
    rapidApiKey?: string;
}
export interface FlightSearchFilters {
    maxPrice?: number;
    maxStops?: number;
    preferredAirlines?: string[];
    departureTimeRange?: {
        earliest: string;
        latest: string;
    };
    maxDuration?: number;
}
export interface FlightRecommendationOptions {
    prioritizePrice: boolean;
    prioritizeConvenience: boolean;
    prioritizeDuration: boolean;
    userTravelStyle: 'budget' | 'mid-range' | 'luxury';
}
export declare class FlightService {
    private readonly amadeuApiKey;
    private readonly amadeuApiSecret;
    private readonly rapidApiKey;
    private amadeuToken;
    private tokenExpiry;
    private readonly enhancedService;
    constructor(config?: FlightServiceConfig);
    /**
     * Search for flights based on trip preferences (legacy method)
     * Now delegates to enhanced service for better functionality
     */
    searchFlights(preferences: TripPreferences, originAirport?: string): Promise<FlightOption[]>;
    /**
     * Enhanced flight search with advanced filtering and recommendations
     */
    searchFlightsEnhanced(request: FlightSearchRequest): Promise<FlightSearchResponse>;
    /**
     * Get flight details by ID
     */
    getFlightDetails(flightId: string): Promise<FlightOption | null>;
    /**
     * Search flights using Amadeus API
     */
    private searchAmadeusFlights;
    /**
     * Search flights using RapidAPI
     */
    private searchRapidApiFlights;
    /**
     * Ensure Amadeus token is valid
     */
    private ensureAmadeusToken;
    /**
     * Parse Amadeus flight response
     */
    private parseAmadeusFlights;
    /**
     * Parse RapidAPI flight response
     */
    private parseRapidApiFlights;
    /**
     * Generate realistic mock flights with real-world pricing
     */
    private generateRealisticMockFlights;
    /**
     * Get Amadeus flight details
     */
    private getAmadeusFlightDetails;
    /**
     * Guess origin airport based on common patterns
     */
    private guessOriginAirport;
    /**
     * Get destination airport code from city name
     */
    private getDestinationAirport;
    /**
     * Calculate base price for destination
     */
    private calculateBasePrice;
    /**
     * Calculate flight duration in minutes
     */
    private calculateFlightDuration;
    /**
     * Calculate return date
     */
    private calculateReturnDate;
    /**
     * Get airline name from code
     */
    private getAirlineName;
    /**
     * Get airport city from code
     */
    private getAirportCity;
    /**
     * Format time from ISO string
     */
    private formatTime;
    /**
     * Format date from ISO string
     */
    private formatDate;
    /**
     * Format duration from minutes
     */
    private formatDuration;
}
//# sourceMappingURL=flight-service.d.ts.map