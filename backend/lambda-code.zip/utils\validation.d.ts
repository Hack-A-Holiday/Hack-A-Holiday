import Joi from 'joi';
import { TripPreferences, BookingRequest } from '../types';
export declare const tripPreferencesSchema: Joi.ObjectSchema<TripPreferences>;
export declare const bookingRequestSchema: Joi.ObjectSchema<BookingRequest>;
export declare function validateTripPreferences(data: any): {
    isValid: boolean;
    data?: TripPreferences;
    errors?: string[];
};
export declare function validateBookingRequest(data: any): {
    isValid: boolean;
    data?: BookingRequest;
    errors?: string[];
};
export declare function validateBudgetAllocation(totalBudget: number, flightCost: number, hotelCost: number, activityCost: number): {
    isValid: boolean;
    message?: string;
    breakdown: any;
};
export declare function validateDateRange(startDate: string, duration: number): {
    isValid: boolean;
    endDate?: string;
    message?: string;
};
export declare const VALID_INTERESTS: string[];
export declare function validateInterests(interests: string[]): {
    isValid: boolean;
    validInterests?: string[];
    invalidInterests?: string[];
};
//# sourceMappingURL=validation.d.ts.map