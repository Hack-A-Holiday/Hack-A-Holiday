import { BaseRepository, RepositoryConfig } from './base-repository';
import { Itinerary, TripPreferences } from '../types';
export declare class TripRepository extends BaseRepository {
    constructor(config?: Partial<RepositoryConfig>);
    /**
     * Create a new trip
     */
    createTrip(preferences: TripPreferences, userId?: string): Promise<string>;
    /**
     * Get trip by ID
     */
    getTripById(tripId: string): Promise<Itinerary | null>;
    /**
     * Update trip itinerary
     */
    updateTripItinerary(tripId: string, itinerary: Itinerary): Promise<Itinerary>;
    /**
     * Update trip status
     */
    updateTripStatus(tripId: string, status: Itinerary['status']): Promise<void>;
    /**
     * Get trips by user ID
     */
    getTripsByUserId(userId: string, limit?: number, lastEvaluatedKey?: Record<string, any>): Promise<{
        trips: Itinerary[];
        lastEvaluatedKey?: Record<string, any>;
    }>;
    /**
     * Get trips by destination
     */
    getTripsByDestination(destination: string, limit?: number): Promise<Itinerary[]>;
    /**
     * Get trips by status
     */
    getTripsByStatus(status: Itinerary['status'], limit?: number): Promise<Itinerary[]>;
    /**
     * Get recent trips (for analytics)
     */
    getRecentTrips(days?: number, limit?: number): Promise<Itinerary[]>;
    /**
     * Get trips by budget range
     */
    getTripsByBudgetRange(minBudget: number, maxBudget: number, limit?: number): Promise<Itinerary[]>;
    /**
     * Delete trip
     */
    deleteTrip(tripId: string): Promise<void>;
    /**
     * Check if trip exists
     */
    tripExists(tripId: string): Promise<boolean>;
    /**
     * Get trip statistics
     */
    getTripStatistics(): Promise<{
        totalTrips: number;
        tripsByStatus: Record<string, number>;
        averageBudget: number;
        popularDestinations: Array<{
            destination: string;
            count: number;
        }>;
    }>;
    /**
     * Search trips by multiple criteria
     */
    searchTrips(criteria: {
        userId?: string;
        destination?: string;
        status?: Itinerary['status'];
        minBudget?: number;
        maxBudget?: number;
        startDate?: string;
        endDate?: string;
    }, limit?: number): Promise<Itinerary[]>;
    /**
     * Helper method to calculate end date
     */
    private calculateEndDate;
}
//# sourceMappingURL=trip-repository.d.ts.map