/**
 * Enhanced Flight Search Lambda Function
 *
 * Provides advanced flight search capabilities with filtering, sorting,
 * and intelligent recommendations. Follows enterprise-grade patterns.
 *
 * @author Travel Companion Team
 * @version 1.0.0
 */
import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * Enhanced Flight Search Handler
 *
 * Handles advanced flight search requests with comprehensive filtering,
 * sorting, and recommendation capabilities.
 */
export declare const handler: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=enhanced-flight-search.d.ts.map