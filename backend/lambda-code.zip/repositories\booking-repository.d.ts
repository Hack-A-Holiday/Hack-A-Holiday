import { BaseRepository, RepositoryConfig } from './base-repository';
import { BookingConfirmation } from '../types';
export declare class BookingRepository extends BaseRepository {
    constructor(config?: Partial<RepositoryConfig>);
    /**
     * Create a new booking
     */
    createBooking(tripId: string, userId: string | undefined, type: BookingConfirmation['type'], itemId: string, itemName: string, cost: number, details: any): Promise<BookingConfirmation>;
    /**
     * Get booking by ID
     */
    getBookingById(bookingId: string): Promise<BookingConfirmation | null>;
    /**
     * Get bookings by trip ID
     */
    getBookingsByTripId(tripId: string, limit?: number): Promise<BookingConfirmation[]>;
    /**
     * Get bookings by user ID
     */
    getBookingsByUserId(userId: string, limit?: number): Promise<BookingConfirmation[]>;
    /**
     * Get bookings by type
     */
    getBookingsByType(type: BookingConfirmation['type'], limit?: number): Promise<BookingConfirmation[]>;
    /**
     * Get bookings by confirmation number
     */
    getBookingByConfirmationNumber(confirmationNumber: string): Promise<BookingConfirmation | null>;
    /**
     * Update booking status
     */
    updateBookingStatus(bookingId: string, itemId: string, type: BookingConfirmation['type'], status: BookingConfirmation['status']): Promise<BookingConfirmation | null>;
    /**
     * Cancel booking
     */
    cancelBooking(bookingId: string, itemId: string, type: BookingConfirmation['type']): Promise<BookingConfirmation | null>;
    /**
     * Delete booking
     */
    deleteBooking(bookingId: string, itemId: string, type: BookingConfirmation['type']): Promise<void>;
    /**
     * Get booking statistics
     */
    getBookingStatistics(): Promise<{
        totalBookings: number;
        bookingsByType: Record<string, number>;
        bookingsByStatus: Record<string, number>;
        totalRevenue: number;
        averageBookingValue: number;
    }>;
    /**
     * Get recent bookings
     */
    getRecentBookings(days?: number, limit?: number): Promise<BookingConfirmation[]>;
    /**
     * Search bookings by multiple criteria
     */
    searchBookings(criteria: {
        tripId?: string;
        userId?: string;
        type?: BookingConfirmation['type'];
        status?: BookingConfirmation['status'];
        minCost?: number;
        maxCost?: number;
        startDate?: string;
        endDate?: string;
    }, limit?: number): Promise<BookingConfirmation[]>;
    /**
     * Generate a unique confirmation number
     */
    private generateConfirmationNumber;
    /**
     * Map database record to BookingConfirmation
     */
    private mapRecordToBooking;
}
//# sourceMappingURL=booking-repository.d.ts.map