"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.googleAuth = googleAuth;
const user_repository_1 = require("../repositories/user-repository");
const auth_service_1 = require("../services/auth-service");
const lambda_utils_1 = require("../utils/lambda-utils");
const userRepository = new user_repository_1.UserRepository();
const authService = new auth_service_1.AuthService();
async function googleAuth(event, context) {
    const requestId = context.awsRequestId;
    try {
        // Parse request body
        const body = (0, lambda_utils_1.parseJsonBody)(event);
        if (!body) {
            return (0, lambda_utils_1.createErrorResponse)(400, 'Request body is required', requestId);
        }
        const { googleToken, name, profilePicture } = body;
        // Validate required fields
        if (!googleToken) {
            return (0, lambda_utils_1.createErrorResponse)(400, 'Google token is required', requestId);
        }
        // Verify Google token
        let googleUserData;
        try {
            googleUserData = await authService.verifyGoogleToken(googleToken);
        }
        catch (error) {
            console.error('Google token verification failed:', error instanceof Error ? error.message : 'Unknown error');
            return (0, lambda_utils_1.createErrorResponse)(401, 'Invalid Google token', requestId);
        }
        // Create or update Google user
        let user;
        try {
            user = await userRepository.createOrUpdateGoogleUser(googleUserData.googleId, googleUserData.email, name || googleUserData.name, profilePicture || googleUserData.profilePicture);
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Failed to create user account';
            return (0, lambda_utils_1.createErrorResponse)(409, errorMessage, requestId);
        }
        // Generate JWT token
        const token = authService.generateToken(authService.createUserResponse(user));
        const response = {
            success: true,
            user: authService.createUserResponse(user),
            token,
            message: 'Google authentication successful',
        };
        return (0, lambda_utils_1.createResponse)(200, response, requestId);
    }
    catch (error) {
        console.error('Google auth error:', error);
        const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
        return (0, lambda_utils_1.createErrorResponse)(500, errorMessage, requestId);
    }
}
//# sourceMappingURL=google-auth.js.map