import { TripPreferences, Itinerary, DayPlan } from '../types';
export declare function calculateTotalCost(itinerary: Partial<Itinerary>): number;
export declare function calculateDayCost(day: DayPlan): number;
export declare function calculateBudgetBreakdown(itinerary: Partial<Itinerary>): {
    flights: number;
    accommodation: number;
    activities: number;
    meals: number;
    transportation: number;
    miscellaneous: number;
};
export declare function optimizeBudget(preferences: TripPreferences, currentCost: number): {
    canOptimize: boolean;
    suggestions: string[];
    targetReductions: {
        flights: number;
        accommodation: number;
        activities: number;
    };
};
export declare function calculateEndDate(startDate: string, duration: number): string;
export declare function getDaysBetween(startDate: string, endDate: string): number;
export declare function generateDateRange(startDate: string, duration: number): string[];
export declare function adjustCostForTravelers(baseCost: number, travelers: number, type: 'per-person' | 'per-room' | 'per-group'): number;
export declare function calculateConfidenceScore(budgetMatch: number, // 0-1, how well we matched the budget
availabilityMatch: number, // 0-1, how many options we found
preferencesMatch: number): number;
export declare function calculateBudgetMatch(actualCost: number, targetBudget: number): number;
export declare function formatCurrency(amount: number, currency?: string): string;
export declare function formatDuration(minutes: number): string;
export declare function formatDate(dateString: string, format?: 'short' | 'long'): string;
//# sourceMappingURL=calculations.d.ts.map