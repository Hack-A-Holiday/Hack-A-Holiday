"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseRepository = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const lib_dynamodb_1 = require("@aws-sdk/lib-dynamodb");
class BaseRepository {
    constructor(config) {
        const dynamoClient = new client_dynamodb_1.DynamoDBClient({
            region: config.region || process.env.AWS_REGION || 'us-east-1',
            ...(config.endpoint && { endpoint: config.endpoint })
        });
        this.client = lib_dynamodb_1.DynamoDBDocumentClient.from(dynamoClient, {
            marshallOptions: {
                convertEmptyValues: false,
                removeUndefinedValues: true,
                convertClassInstanceToMap: false,
            },
            unmarshallOptions: {
                wrapNumbers: false,
            },
        });
        this.tableName = config.tableName;
    }
    /**
     * Get a single item by primary key
     */
    async getItem(key) {
        try {
            const command = new lib_dynamodb_1.GetCommand({
                TableName: this.tableName,
                Key: key,
            });
            const result = await this.client.send(command);
            return result.Item || null;
        }
        catch (error) {
            console.error('Error getting item:', error);
            throw new Error(`Failed to get item: ${error}`);
        }
    }
    /**
     * Put an item (create or replace)
     */
    async putItem(item) {
        try {
            const command = new lib_dynamodb_1.PutCommand({
                TableName: this.tableName,
                Item: {
                    ...item,
                    updatedAt: new Date().toISOString(),
                },
            });
            await this.client.send(command);
        }
        catch (error) {
            console.error('Error putting item:', error);
            throw new Error(`Failed to put item: ${error}`);
        }
    }
    /**
     * Update an item
     */
    async updateItem(key, options) {
        try {
            const command = new lib_dynamodb_1.UpdateCommand({
                TableName: this.tableName,
                Key: key,
                UpdateExpression: options.updateExpression,
                ExpressionAttributeNames: options.expressionAttributeNames,
                ExpressionAttributeValues: {
                    ...options.expressionAttributeValues,
                    ':updatedAt': new Date().toISOString(),
                },
                ConditionExpression: options.conditionExpression,
                ReturnValues: 'ALL_NEW',
            });
            const result = await this.client.send(command);
            return result.Attributes;
        }
        catch (error) {
            console.error('Error updating item:', error);
            throw new Error(`Failed to update item: ${error}`);
        }
    }
    /**
     * Delete an item
     */
    async deleteItem(key) {
        try {
            const command = new lib_dynamodb_1.DeleteCommand({
                TableName: this.tableName,
                Key: key,
            });
            await this.client.send(command);
        }
        catch (error) {
            console.error('Error deleting item:', error);
            throw new Error(`Failed to delete item: ${error}`);
        }
    }
    /**
     * Query items
     */
    async query(keyConditionExpression, options = {}) {
        try {
            const command = new lib_dynamodb_1.QueryCommand({
                TableName: this.tableName,
                KeyConditionExpression: keyConditionExpression,
                ExpressionAttributeNames: options.expressionAttributeNames,
                ExpressionAttributeValues: options.expressionAttributeValues,
                FilterExpression: options.filterExpression,
                Limit: options.limit,
                ExclusiveStartKey: options.exclusiveStartKey,
                ScanIndexForward: options.scanIndexForward,
            });
            const result = await this.client.send(command);
            return {
                items: result.Items || [],
                lastEvaluatedKey: result.LastEvaluatedKey,
            };
        }
        catch (error) {
            console.error('Error querying items:', error);
            throw new Error(`Failed to query items: ${error}`);
        }
    }
    /**
     * Query items using GSI
     */
    async queryGSI(indexName, keyConditionExpression, options = {}) {
        try {
            const command = new lib_dynamodb_1.QueryCommand({
                TableName: this.tableName,
                IndexName: indexName,
                KeyConditionExpression: keyConditionExpression,
                ExpressionAttributeNames: options.expressionAttributeNames,
                ExpressionAttributeValues: options.expressionAttributeValues,
                FilterExpression: options.filterExpression,
                Limit: options.limit,
                ExclusiveStartKey: options.exclusiveStartKey,
                ScanIndexForward: options.scanIndexForward,
            });
            const result = await this.client.send(command);
            return {
                items: result.Items || [],
                lastEvaluatedKey: result.LastEvaluatedKey,
            };
        }
        catch (error) {
            console.error('Error querying GSI:', error);
            throw new Error(`Failed to query GSI: ${error}`);
        }
    }
    /**
     * Scan table (use sparingly)
     */
    async scan(options = {}) {
        try {
            const command = new lib_dynamodb_1.ScanCommand({
                TableName: this.tableName,
                FilterExpression: options.filterExpression,
                ExpressionAttributeNames: options.expressionAttributeNames,
                ExpressionAttributeValues: options.expressionAttributeValues,
                Limit: options.limit,
                ExclusiveStartKey: options.exclusiveStartKey,
            });
            const result = await this.client.send(command);
            return {
                items: result.Items || [],
                lastEvaluatedKey: result.LastEvaluatedKey,
            };
        }
        catch (error) {
            console.error('Error scanning table:', error);
            throw new Error(`Failed to scan table: ${error}`);
        }
    }
    /**
     * Batch get items (up to 100 items)
     */
    async batchGetItems(keys) {
        if (keys.length === 0)
            return [];
        if (keys.length > 100) {
            throw new Error('Cannot batch get more than 100 items at once');
        }
        try {
            // For simplicity, we'll use individual gets
            // In production, you might want to use BatchGetCommand
            const promises = keys.map(key => this.getItem(key));
            const results = await Promise.all(promises);
            return results.filter(item => item !== null);
        }
        catch (error) {
            console.error('Error batch getting items:', error);
            throw new Error(`Failed to batch get items: ${error}`);
        }
    }
    /**
     * Check if item exists
     */
    async itemExists(key) {
        const item = await this.getItem(key);
        return item !== null;
    }
    /**
     * Get table name (useful for testing)
     */
    getTableName() {
        return this.tableName;
    }
}
exports.BaseRepository = BaseRepository;
//# sourceMappingURL=base-repository.js.map