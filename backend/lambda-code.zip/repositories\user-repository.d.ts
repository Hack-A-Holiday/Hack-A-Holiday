import { BaseRepository, RepositoryConfig } from './base-repository';
import { UserProfile } from '../types';
export declare class UserRepository extends BaseRepository {
    constructor(config?: Partial<RepositoryConfig>);
    /**
     * Create a new user (normal auth)
     */
    createUser(userData: Omit<UserProfile, 'id' | 'createdAt' | 'updatedAt'>): Promise<UserProfile>;
    /**
     * Get user by ID
     */
    getUserById(userId: string): Promise<UserProfile | null>;
    /**
     * Get user by email
     */
    getUserByEmail(email: string): Promise<UserProfile | null>;
    /**
     * Update user preferences
     */
    updateUserPreferences(userId: string, preferences: Partial<UserProfile['preferences']>): Promise<UserProfile | null>;
    /**
     * Add trip to user's history
     */
    addTripToHistory(userId: string, tripId: string): Promise<void>;
    /**
     * Remove trip from user's history
     */
    removeTripFromHistory(userId: string, tripId: string): Promise<void>;
    /**
     * Get user's trip history with pagination
     */
    getUserTripHistory(userId: string, limit?: number, lastEvaluatedKey?: Record<string, any>): Promise<{
        tripIds: string[];
        lastEvaluatedKey?: Record<string, any>;
    }>;
    /**
     * Delete user
     */
    deleteUser(userId: string): Promise<void>;
    /**
     * Check if user exists
     */
    userExists(userId: string): Promise<boolean>;
    /**
     * Check if email is already registered
     */
    emailExists(email: string): Promise<boolean>;
    /**
     * Get users by travel style (for analytics/recommendations)
     */
    getUsersByTravelStyle(travelStyle: 'budget' | 'mid-range' | 'luxury', limit?: number): Promise<UserProfile[]>;
    /**
     * Get users with similar interests (for recommendations)
     */
    getUsersWithSimilarInterests(interests: string[], limit?: number): Promise<UserProfile[]>;
    /**
     * Authenticate user with email and password
     */
    authenticateUser(email: string, password: string): Promise<UserProfile | null>;
    /**
     * Create or update user from Google OAuth
     */
    createOrUpdateGoogleUser(googleId: string, email: string, name?: string, profilePicture?: string): Promise<UserProfile>;
    /**
     * Get user by Google ID
     */
    getUserByGoogleId(googleId: string): Promise<UserProfile | null>;
    /**
     * Update user data
     */
    updateUser(userId: string, updateData: Partial<UserProfile>): Promise<void>;
    /**
     * Update last login time
     */
    updateLastLogin(userId: string): Promise<void>;
    /**
     * Update user password (for normal auth users)
     */
    updatePassword(userId: string, newPassword: string): Promise<boolean>;
    /**
     * Generate and store password reset token for user
     */
    generatePasswordResetToken(email: string): Promise<{
        token: string;
        expiry: string;
    } | null>;
    /**
     * Verify password reset token and update password
     */
    resetPasswordWithToken(token: string, newPassword: string): Promise<boolean>;
    /**
     * Verify if password reset token is valid
     */
    verifyPasswordResetToken(token: string): Promise<{
        valid: boolean;
        email?: string;
    }>;
    /**
     * Clear expired reset tokens (can be called periodically)
     */
    clearExpiredResetTokens(): Promise<number>;
    /**
     * Map database record to UserProfile
     */
    private mapRecordToProfile;
}
//# sourceMappingURL=user-repository.d.ts.map