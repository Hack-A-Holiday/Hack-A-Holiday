import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
/**
 * Simple plan trip function for testing - no dependencies
 */
export declare const planTrip: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const getTrip: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const listTrips: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=plan-trip-simple.d.ts.map