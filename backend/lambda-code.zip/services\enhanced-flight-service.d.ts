/**
 * Enhanced Flight Search Service
 *
 * Enterprise-grade flight search service with advanced filtering, sorting,
 * and recommendation capabilities. Follows Google/Meta engineering standards.
 *
 * @author Travel Companion Team
 * @version 1.0.0
 */
import { FlightOption, FlightSearchRequest, FlightSearchResponse, FlightSearchMetrics, TripPreferences } from '../types';
/**
 * Configuration for the enhanced flight service
 */
export interface EnhancedFlightServiceConfig {
    amadeusApiKey?: string;
    amadeusApiSecret?: string;
    rapidApiKey?: string;
    skyscannerApiKey?: string;
    timeout?: number;
    retryAttempts?: number;
    cacheEnabled?: boolean;
    cacheTimeout?: number;
}
/**
 * Enhanced Flight Search Service
 *
 * Provides comprehensive flight search with multiple API providers,
 * advanced filtering, intelligent recommendations, and robust fallback logic.
 */
export declare class EnhancedFlightService {
    private readonly config;
    private readonly recommendationEngine;
    private readonly httpClient;
    private readonly providers;
    private amadeusToken;
    private tokenExpiry;
    private searchCache;
    constructor(config?: EnhancedFlightServiceConfig);
    /**
     * Main flight search method with comprehensive functionality
     */
    searchFlights(request: FlightSearchRequest): Promise<FlightSearchResponse>;
    /**
     * Search flights using trip preferences (legacy compatibility)
     */
    searchFlightsFromPreferences(preferences: TripPreferences, originAirport?: string): Promise<FlightOption[]>;
    /**
     * Get flight details by ID
     */
    getFlightDetails(flightId: string): Promise<FlightOption | null>;
    /**
     * Get search metrics for analytics
     */
    getSearchMetrics(searchId: string, request: FlightSearchRequest): FlightSearchMetrics;
    private initializeProviders;
    private searchMultipleProviders;
    private searchWithProvider;
    private searchAmadeusFlights;
    private searchRapidApiFlights;
    private buildKiwiApiUrl;
    private searchSkyscannerFlights;
    private generateMockFlights;
    private generateFallbackFlights;
    private combineAndDeduplicateResults;
    private isBetterFlight;
    private calculateRecommendationScores;
    private buildSearchResponse;
    private generateCacheKey;
    private getCachedResult;
    private cacheResult;
    private validateSearchRequest;
    private getDefaultPreferences;
    private mapTravelStyleToCabinClass;
    private mapPreferencesToSearchPreferences;
    private ensureAmadeusToken;
    private parseAmadeusFlights;
    private parseKiwiFlights;
    private parseRapidApiFlights;
    private getAmadeusFlightDetails;
    private guessOriginAirport;
    private getDestinationAirport;
    private calculateBasePrice;
    private calculateFlightDuration;
    private calculateReturnDate;
    private getAirlineName;
    private getAirportCity;
    private formatTime;
    private parseDurationToMinutes;
    private formatDate;
    private formatDuration;
}
//# sourceMappingURL=enhanced-flight-service.d.ts.map