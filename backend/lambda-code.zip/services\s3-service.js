"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3Service = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
class S3Service {
    constructor(config) {
        this.client = new client_s3_1.S3Client({
            region: config.region || process.env.AWS_REGION || 'us-east-1',
            ...(config.endpoint && { endpoint: config.endpoint, forcePathStyle: true })
        });
        this.bucketName = config.bucketName;
    }
    /**
     * Upload itinerary as JSON file
     */
    async uploadItinerary(userId, tripId, itinerary) {
        const key = this.getItineraryKey(userId, tripId, 'json');
        const content = JSON.stringify(itinerary, null, 2);
        await this.uploadFile(key, content, {
            contentType: 'application/json',
            metadata: {
                tripId,
                userId: userId || 'anonymous',
                destination: itinerary.destination,
                totalCost: itinerary.totalCost.toString(),
            },
            cacheControl: 'max-age=3600', // Cache for 1 hour
        });
        return key;
    }
    /**
     * Upload itinerary as PDF (placeholder - would need PDF generation library)
     */
    async uploadItineraryPDF(userId, tripId, pdfBuffer) {
        const key = this.getItineraryKey(userId, tripId, 'pdf');
        await this.uploadFile(key, pdfBuffer, {
            contentType: 'application/pdf',
            metadata: {
                tripId,
                userId: userId || 'anonymous',
                type: 'itinerary-pdf',
            },
            cacheControl: 'max-age=86400', // Cache for 24 hours
        });
        return key;
    }
    /**
     * Upload booking confirmations
     */
    async uploadBookingConfirmations(userId, tripId, confirmations) {
        const key = this.getBookingConfirmationsKey(userId, tripId);
        const content = JSON.stringify(confirmations, null, 2);
        await this.uploadFile(key, content, {
            contentType: 'application/json',
            metadata: {
                tripId,
                userId: userId || 'anonymous',
                type: 'booking-confirmations',
                count: confirmations.length.toString(),
            },
        });
        return key;
    }
    /**
     * Generic file upload
     */
    async uploadFile(key, content, options = {}) {
        try {
            const command = new client_s3_1.PutObjectCommand({
                Bucket: this.bucketName,
                Key: key,
                Body: content,
                ContentType: options.contentType || 'application/octet-stream',
                Metadata: options.metadata,
                CacheControl: options.cacheControl,
                Expires: options.expires,
            });
            await this.client.send(command);
        }
        catch (error) {
            console.error('Error uploading file to S3:', error);
            throw new Error(`Failed to upload file: ${error}`);
        }
    }
    /**
     * Get file content
     */
    async getFile(key) {
        try {
            const command = new client_s3_1.GetObjectCommand({
                Bucket: this.bucketName,
                Key: key,
            });
            const response = await this.client.send(command);
            if (!response.Body) {
                throw new Error('No file content received');
            }
            // Convert stream to buffer
            const chunks = [];
            const reader = response.Body.transformToWebStream().getReader();
            while (true) {
                const { done, value } = await reader.read();
                if (done)
                    break;
                chunks.push(value);
            }
            return Buffer.concat(chunks);
        }
        catch (error) {
            console.error('Error getting file from S3:', error);
            throw new Error(`Failed to get file: ${error}`);
        }
    }
    /**
     * Get itinerary from S3
     */
    async getItinerary(userId, tripId) {
        try {
            const key = this.getItineraryKey(userId, tripId, 'json');
            const buffer = await this.getFile(key);
            const content = buffer.toString('utf-8');
            return JSON.parse(content);
        }
        catch (error) {
            console.error('Error getting itinerary from S3:', error);
            return null;
        }
    }
    /**
     * Generate signed URL for file access
     */
    async getSignedUrl(key, options = {}) {
        try {
            const command = new client_s3_1.GetObjectCommand({
                Bucket: this.bucketName,
                Key: key,
                ResponseContentType: options.responseContentType,
                ResponseContentDisposition: options.responseContentDisposition,
            });
            return await (0, s3_request_presigner_1.getSignedUrl)(this.client, command, {
                expiresIn: options.expiresIn || 3600, // 1 hour default
            });
        }
        catch (error) {
            console.error('Error generating signed URL:', error);
            throw new Error(`Failed to generate signed URL: ${error}`);
        }
    }
    /**
     * Generate signed URL for itinerary
     */
    async getItinerarySignedUrl(userId, tripId, format = 'json', options = {}) {
        const key = this.getItineraryKey(userId, tripId, format);
        const urlOptions = {
            ...options,
            responseContentType: format === 'pdf' ? 'application/pdf' : 'application/json',
            responseContentDisposition: `attachment; filename="itinerary-${tripId}.${format}"`,
        };
        return await this.getSignedUrl(key, urlOptions);
    }
    /**
     * Delete file
     */
    async deleteFile(key) {
        try {
            const command = new client_s3_1.DeleteObjectCommand({
                Bucket: this.bucketName,
                Key: key,
            });
            await this.client.send(command);
        }
        catch (error) {
            console.error('Error deleting file from S3:', error);
            throw new Error(`Failed to delete file: ${error}`);
        }
    }
    /**
     * Delete all files for a trip
     */
    async deleteTripFiles(userId, tripId) {
        const prefix = this.getTripPrefix(userId, tripId);
        try {
            // List all objects with the trip prefix
            const listCommand = new client_s3_1.ListObjectsV2Command({
                Bucket: this.bucketName,
                Prefix: prefix,
            });
            const response = await this.client.send(listCommand);
            if (response.Contents && response.Contents.length > 0) {
                // Delete each file
                const deletePromises = response.Contents.map(object => {
                    if (object.Key) {
                        return this.deleteFile(object.Key);
                    }
                }).filter(Boolean);
                await Promise.all(deletePromises);
            }
        }
        catch (error) {
            console.error('Error deleting trip files:', error);
            throw new Error(`Failed to delete trip files: ${error}`);
        }
    }
    /**
     * Check if file exists
     */
    async fileExists(key) {
        try {
            const command = new client_s3_1.HeadObjectCommand({
                Bucket: this.bucketName,
                Key: key,
            });
            await this.client.send(command);
            return true;
        }
        catch (error) {
            if (error.name === 'NotFound' || error.$metadata?.httpStatusCode === 404) {
                return false;
            }
            throw error;
        }
    }
    /**
     * Get file metadata
     */
    async getFileMetadata(key) {
        try {
            const command = new client_s3_1.HeadObjectCommand({
                Bucket: this.bucketName,
                Key: key,
            });
            const response = await this.client.send(command);
            return {
                contentType: response.ContentType,
                contentLength: response.ContentLength,
                lastModified: response.LastModified,
                metadata: response.Metadata,
            };
        }
        catch (error) {
            if (error.name === 'NotFound' || error.$metadata?.httpStatusCode === 404) {
                return null;
            }
            throw error;
        }
    }
    /**
     * List files for a user
     */
    async listUserFiles(userId, prefix, maxKeys = 100) {
        try {
            const fullPrefix = prefix
                ? `users/${userId}/${prefix}`
                : `users/${userId}/`;
            const command = new client_s3_1.ListObjectsV2Command({
                Bucket: this.bucketName,
                Prefix: fullPrefix,
                MaxKeys: maxKeys,
            });
            const response = await this.client.send(command);
            return (response.Contents || []).map(object => ({
                key: object.Key,
                size: object.Size,
                lastModified: object.LastModified,
            }));
        }
        catch (error) {
            console.error('Error listing user files:', error);
            throw new Error(`Failed to list user files: ${error}`);
        }
    }
    /**
     * Generate key for itinerary file
     */
    getItineraryKey(userId, tripId, format) {
        const userPath = userId ? `users/${userId}` : 'anonymous';
        return `${userPath}/trips/${tripId}/itinerary.${format}`;
    }
    /**
     * Generate key for booking confirmations
     */
    getBookingConfirmationsKey(userId, tripId) {
        const userPath = userId ? `users/${userId}` : 'anonymous';
        return `${userPath}/trips/${tripId}/booking-confirmations.json`;
    }
    /**
     * Generate prefix for all trip files
     */
    getTripPrefix(userId, tripId) {
        const userPath = userId ? `users/${userId}` : 'anonymous';
        return `${userPath}/trips/${tripId}/`;
    }
    /**
     * Get bucket name (useful for testing)
     */
    getBucketName() {
        return this.bucketName;
    }
}
exports.S3Service = S3Service;
//# sourceMappingURL=s3-service.js.map