import { APIGatewayProxyResult } from 'aws-lambda';
export declare const addCorsHeaders: (response: APIGatewayProxyResult) => APIGatewayProxyResult;
//# sourceMappingURL=cors.d.ts.map