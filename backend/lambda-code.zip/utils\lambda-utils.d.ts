import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
import { ApiError } from '../types';
export interface LambdaResponse {
    statusCode: number;
    headers?: Record<string, string>;
    body: string;
}
export interface RequestContext {
    requestId: string;
    userId?: string;
    correlationId: string;
    startTime: number;
}
/**
 * Create standardized API response
 */
export declare function createResponse(statusCode: number, data: any, requestId: string, headers?: Record<string, string>): APIGatewayProxyResult;
/**
 * Create error response
 */
export declare function createErrorResponse(statusCode: number, error: string | ApiError, requestId: string): APIGatewayProxyResult;
/**
 * Parse JSON body from API Gateway event
 */
export declare function parseJsonBody<T = any>(event: APIGatewayProxyEvent): T | null;
/**
 * Extract user ID from event (from JWT token, API key, etc.)
 */
export declare function extractUserId(event: APIGatewayProxyEvent): string | undefined;
/**
 * Create request context for tracking
 */
export declare function createRequestContext(event: APIGatewayProxyEvent): RequestContext;
/**
 * Log request details
 */
export declare function logRequest(event: APIGatewayProxyEvent, context: Context, requestContext: RequestContext): void;
/**
 * Log response details
 */
export declare function logResponse(response: APIGatewayProxyResult, requestContext: RequestContext, error?: Error): void;
/**
 * Validate required environment variables
 */
export declare function validateEnvironment(requiredVars: string[]): void;
/**
 * Handle CORS preflight requests
 */
export declare function handleCorsPreflightRequest(event: APIGatewayProxyEvent): APIGatewayProxyResult | null;
/**
 * Middleware wrapper for Lambda functions
 */
export declare function withMiddleware(handler: (event: APIGatewayProxyEvent, context: Context, requestContext: RequestContext) => Promise<APIGatewayProxyResult>): (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>;
/**
 * Apply rate limiting to requests
 */
export declare function applyRateLimit(event: APIGatewayProxyEvent, requestContext: RequestContext): APIGatewayProxyResult | null;
/**
 * Validate request method
 */
export declare function validateMethod(event: APIGatewayProxyEvent, allowedMethods: string[]): APIGatewayProxyResult | null;
/**
 * Extract pagination parameters
 */
export declare function extractPaginationParams(event: APIGatewayProxyEvent): {
    limit: number;
    offset: number;
    lastEvaluatedKey?: string;
};
//# sourceMappingURL=lambda-utils.d.ts.map