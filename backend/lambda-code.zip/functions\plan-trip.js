"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.listTrips = exports.getTrip = exports.planTrip = void 0;
const client_bedrock_runtime_1 = require("@aws-sdk/client-bedrock-runtime");
// Initialize Bedrock client  
// AWS_REGION is automatically provided by Lambda runtime
const bedrockClient = new client_bedrock_runtime_1.BedrockRuntimeClient({
    region: 'us-east-1', // Hardcode region since we're deployed in us-east-1
});
/**
 * Invoke Claude model with the given prompt
 */
async function invokeModel(prompt) {
    try {
        console.log('🤖 Initializing Bedrock request...');
        const input = {
            modelId: 'anthropic.claude-3-sonnet-20240229-v1:0', // Claude 3 Sonnet (most widely available)
            contentType: 'application/json',
            accept: 'application/json',
            body: JSON.stringify({
                anthropic_version: 'bedrock-2023-05-31',
                max_tokens: 4000,
                temperature: 0.7,
                messages: [
                    {
                        role: 'user',
                        content: prompt
                    }
                ]
            })
        };
        console.log('📤 Sending request to Bedrock...');
        const command = new client_bedrock_runtime_1.InvokeModelCommand(input);
        const response = await bedrockClient.send(command);
        console.log('📥 Received response from Bedrock');
        if (!response.body) {
            throw new Error('No response body from Bedrock');
        }
        const responseBody = JSON.parse(new TextDecoder().decode(response.body));
        console.log('✅ Successfully parsed Bedrock response');
        return responseBody.content[0].text;
    }
    catch (error) {
        console.error('❌ Bedrock invocation failed:', error);
        throw error;
    }
}
const planTrip = async (event) => {
    console.log('🤖 AI-Powered planTrip handler started with Claude Bedrock');
    const headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE,PATCH,HEAD,OPTIONS'
    };
    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 204,
            headers,
            body: ''
        };
    }
    try {
        console.log('Event received:', JSON.stringify({
            httpMethod: event.httpMethod,
            path: event.path,
            body: event.body ? event.body.substring(0, 200) : 'no body'
        }));
        let body;
        if (event.body) {
            body = JSON.parse(event.body);
        }
        // Handle both direct body format and nested preferences format
        const preferences = body?.preferences || body || {};
        const destination = preferences.destination || 'Paris, France';
        const duration = preferences.duration || 5;
        const budget = preferences.budget || 1000;
        const interests = preferences.interests || ['culture', 'food'];
        const travelers = preferences.travelers || 1;
        const startDate = preferences.startDate || new Date().toISOString().split('T')[0];
        const travelStyle = preferences.travelStyle || 'mid-range';
        console.log(`🌍 Using Claude AI to generate comprehensive travel plan for: ${destination}`);
        // Generate a comprehensive trip itinerary using Claude AI
        const tripId = `trip-${Date.now()}`;
        // Create comprehensive prompt for Claude
        const prompt = `You are an expert travel planner with deep knowledge of destinations worldwide. Create a comprehensive ${duration}-day travel itinerary for ${destination}.

TRIP DETAILS:
- Destination: ${destination}
- Budget: $${budget} total
- Duration: ${duration} days
- Travelers: ${travelers}
- Start Date: ${startDate}
- Travel Style: ${travelStyle}
- Interests: ${interests.join(', ')}

Please provide a detailed response in the following JSON format:
{
  "destination": "${destination}",
  "duration": ${duration},
  "totalCost": estimated_total_cost,
  "overview": {
    "destination": "${destination}",
    "bestTimeToVisit": "best months to visit",
    "currency": "local currency",
    "language": "local language(s)",
    "topHighlights": ["highlight1", "highlight2", "highlight3"]
  },
  "dailyPlans": [
    {
      "day": 1,
      "date": "YYYY-MM-DD",
      "theme": "arrival day theme",
      "activities": {
        "morning": [
          {
            "name": "Activity Name",
            "description": "what to do",
            "duration": "2 hours"
          }
        ],
        "afternoon": [
          {
            "name": "Activity Name", 
            "description": "what to do",
            "duration": "3 hours"
          }
        ],
        "evening": [
          {
            "name": "Activity Name",
            "description": "what to do", 
            "duration": "2 hours"
          }
        ]
      },
      "meals": {
        "breakfast": {
          "name": "Restaurant/Place Name",
          "cuisine": "cuisine type",
          "description": "why recommended"
        },
        "lunch": {
          "name": "Restaurant/Place Name",
          "cuisine": "cuisine type", 
          "description": "why recommended"
        },
        "dinner": {
          "name": "Restaurant/Place Name",
          "cuisine": "cuisine type",
          "description": "why recommended"
        }
      },
      "transportation": "how to get around today",
      "totalCost": daily_cost_estimate
    }
  ],
  "travelTips": [
    "practical tip 1",
    "practical tip 2",
    "practical tip 3"
  ],
  "emergencyInfo": {
    "emergency": "emergency numbers",
    "embassy": "embassy contact info",
    "hospitalContact": "hospital information"
  }
}

IMPORTANT REQUIREMENTS:
1. Provide accurate, real places and attractions specific to ${destination}
2. Ensure activities match the interests: ${interests.join(', ')}
3. Keep total cost within $${budget} budget
4. Suggest ${travelStyle} level accommodations and restaurants
5. Include local cultural insights and authentic experiences
6. Provide practical transportation advice
7. Include emergency information for the destination
8. Make sure daily activities are geographically logical
9. Balance must-see attractions with local hidden gems
10. Ensure response is valid JSON format

Generate a detailed, authentic itinerary that a local travel expert would create.`;
        try {
            console.log('🤖 Invoking Claude model via Bedrock...');
            // Generate the itinerary using AI
            const aiResponse = await invokeModel(prompt);
            const itinerary = JSON.parse(aiResponse);
            console.log('✅ Generated AI itinerary successfully');
            const detailedResponse = {
                success: true,
                tripId,
                itinerary: {
                    id: tripId,
                    ...itinerary,
                    travelers: travelers,
                    status: 'ready',
                    realTimeData: {
                        flightsFound: Math.floor(Math.random() * 20) + 5,
                        hotelsFound: Math.floor(Math.random() * 50) + 10,
                        activitiesFound: itinerary.dailyPlans?.reduce((sum, day) => sum + (day.activities?.morning?.length || 0) +
                            (day.activities?.afternoon?.length || 0) +
                            (day.activities?.evening?.length || 0), 0) || 0,
                        weatherForecast: getWeatherForecast(destination),
                        lastUpdated: new Date().toISOString()
                    },
                    createdAt: new Date().toISOString()
                },
                message: `🤖 AI-powered ${duration}-day travel itinerary created for ${destination}! Powered by Claude Bedrock.`
            };
            console.log('🎉 Returning AI-generated travel plan');
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify(detailedResponse)
            };
        }
        catch (bedrockError) {
            console.error('❌ Bedrock service error:', bedrockError);
            // Fallback to basic itinerary if Bedrock fails
            const fallbackItinerary = generateFallbackItinerary(destination, duration, budget, interests, startDate);
            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    success: true,
                    tripId,
                    itinerary: {
                        id: tripId,
                        ...fallbackItinerary,
                        travelers: travelers,
                        status: 'ready',
                        realTimeData: {
                            flightsFound: Math.floor(Math.random() * 15) + 3,
                            hotelsFound: Math.floor(Math.random() * 30) + 8,
                            activitiesFound: Math.floor(Math.random() * 20) + 10,
                            weatherForecast: getWeatherForecast(destination),
                            lastUpdated: new Date().toISOString()
                        },
                        createdAt: new Date().toISOString()
                    },
                    message: `📋 Basic ${duration}-day travel itinerary created for ${destination}! (Fallback mode - Claude unavailable)`
                })
            };
        }
    }
    catch (error) {
        console.error('💥 Error in AI travel planner:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({
                success: false,
                error: `Internal error: ${error}`,
                timestamp: new Date().toISOString()
            })
        };
    }
};
exports.planTrip = planTrip;
// Fallback itinerary generator
function generateFallbackItinerary(destination, duration, budget, interests, startDate) {
    const dailyBudget = Math.round(budget / duration);
    return {
        destination: destination,
        duration: duration,
        totalCost: budget,
        overview: {
            destination: destination,
            bestTimeToVisit: "Spring to Fall",
            currency: "Local currency",
            language: "Local language",
            topHighlights: ["City center", "Cultural attractions", "Local cuisine"]
        },
        dailyPlans: Array.from({ length: duration }, (_, index) => {
            const day = index + 1;
            const date = new Date(startDate);
            date.setDate(date.getDate() + index);
            return {
                day: day,
                date: date.toISOString().split('T')[0],
                theme: getGenericDayTheme(day, duration),
                activities: {
                    morning: [{
                            name: `Morning ${interests[0] || 'sightseeing'} activity`,
                            description: `Explore ${destination}'s ${interests[0] || 'main attractions'}`,
                            duration: "3 hours"
                        }],
                    afternoon: [{
                            name: `Afternoon ${interests[1] || 'cultural'} experience`,
                            description: `Discover local ${interests[1] || 'culture and history'}`,
                            duration: "4 hours"
                        }],
                    evening: [{
                            name: "Evening dining and relaxation",
                            description: "Experience local cuisine and atmosphere",
                            duration: "2 hours"
                        }]
                },
                meals: {
                    breakfast: {
                        name: "Local breakfast spot",
                        cuisine: "Local",
                        description: "Start your day with authentic local breakfast"
                    },
                    lunch: {
                        name: "Traditional restaurant",
                        cuisine: "Traditional",
                        description: "Authentic local lunch experience"
                    },
                    dinner: {
                        name: "Recommended dinner venue",
                        cuisine: "Local specialties",
                        description: "End your day with signature local dishes"
                    }
                },
                transportation: "Public transport and walking",
                totalCost: dailyBudget
            };
        }),
        travelTips: [
            "Research local customs and etiquette",
            "Keep important documents safe",
            "Learn basic local phrases",
            "Stay hydrated and dress appropriately"
        ],
        emergencyInfo: {
            emergency: "Contact local emergency services",
            embassy: "Contact your embassy",
            hospitalContact: "Local hospital information"
        }
    };
}
function getGenericDayTheme(day, totalDays) {
    const themes = [
        'Arrival & City Overview',
        'Cultural Exploration',
        'Local Experiences',
        'Adventure & Discovery',
        'Relaxation & Shopping',
        'Hidden Gems',
        'Departure & Last Discoveries'
    ];
    if (day === 1)
        return 'Arrival & City Overview';
    if (day === totalDays)
        return 'Departure & Last Discoveries';
    return themes[day % themes.length] || 'Exploration Day';
}
function getWeatherForecast(destination) {
    const weather = {
        'Mumbai': 'Warm and humid, 28-32°C',
        'Paris': 'Mild and pleasant, 18-22°C',
        'Tokyo': 'Comfortable, 20-25°C',
        'Marrakech': 'Warm and dry, 25-30°C',
        'London': 'Cool and cloudy, 12-18°C',
        'New York': 'Variable, 15-23°C',
        'Barcelona': 'Mediterranean, 20-26°C'
    };
    const cityName = destination.split(',')[0];
    return weather[cityName] || 'Pleasant weather expected';
}
// Stub exports for other functions
const getTrip = async (event) => {
    return {
        statusCode: 501,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'Get trip not implemented' })
    };
};
exports.getTrip = getTrip;
const listTrips = async (event) => {
    return {
        statusCode: 501,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ error: 'List trips not implemented' })
    };
};
exports.listTrips = listTrips;
//# sourceMappingURL=plan-trip.js.map