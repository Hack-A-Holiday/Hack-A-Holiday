import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';
export declare function withCorsHeaders(handler: (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>): (event: APIGatewayProxyEvent, context: Context) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=cors-middleware.d.ts.map